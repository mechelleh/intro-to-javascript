var name = prompt("What is your name?");
var last = prompt("What is your last name?");

document.body.innerHTML = name+" "+last;