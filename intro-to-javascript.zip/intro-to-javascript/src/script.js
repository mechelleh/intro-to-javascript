var name = prompt("What is your name?");
var color = prompt("What is your favorite color:");

document.body.innerHTML = "My name is"+" "+ name +" "+ "and my favorite color is"+ " "+ color +".";